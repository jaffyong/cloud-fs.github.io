#!/bin/sh
EXEPATH=$1
DESTPATH=$2
SRCPATH=$3

rm -f "$EXEPATH.tmp"
mv "$EXEPATH" "$EXEPATH.tmp"
cp -r "$SRCPATH"/* "$DESTPATH"
killall -TERM clouddrive
killall -TERM clouddrive
"$EXEPATH" &